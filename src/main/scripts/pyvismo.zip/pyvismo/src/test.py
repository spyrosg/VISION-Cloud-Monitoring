from vismo import VisionMonitoring, Resource, XDAS_EventTypes, XDAS_Outcomes
from uuid import UUID
from random import random

def main():
    src = "http://147.102.19.45/myvisionhost/ManagerObject/createObjectReplica"
    dst = "http://10.0.2.111:8080/vismo/Monitoring/cloud"
    
    component_id = UUID('{12345678-1234-5678-1234-567812345678}')
    
    resource_bw_int  = Resource( "internal-bandwidth", int( random() * 3096 ), "container-foo", "object-bar", "tenant-hallo" )
    resource_bw_ext  = Resource( "external-bandwidth", int( random() * 3096 ), "container-foo", None, "tenant-hallo" )
    resource_disk = Resource( "storage", int( random() * 1024 ), "container-foo", None, "tenant-hallo" );
    
    resources = [ resource_bw_ext.encode(), resource_bw_int.encode(), resource_disk.encode() ];
    # resources = []
    parameters = {'container' : 'some-container'}
    # parameters = {}
    
    user = None
    tenant = None
    
    mtr = VisionMonitoring(component_id);
    mtr.log( src, dst, user, tenant,
             XDAS_EventTypes['XDAS_AE_MODIFY_DATA_ITEM_ASSOC_CONTEXT'],
             XDAS_Outcomes['XDAS_OUT_SUCCESS'],
             parameters, resources);


if __name__ == '__main__':
    main()
