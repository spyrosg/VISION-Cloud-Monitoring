from urlparse import urlparse
from socket import gethostbyname
from time import time
import json
from restful_lib import Connection


class Resource():
    
    rsc_type = None
    value = None
    unit = None
    
    def __init__(self, rsc_type, value, unit):
        self.rsc_type = rsc_type
        self.value = value
        self.unit = unit
        
    def encode(self):
        return { 'type' : self.rsc_type, 'value' : int(self.value), 'unit' : self.unit }


class VisionMonitoring():

    uuid = None
    topicname = "vision.xdas";
    compliance_url = "tcp://10.0.2.71:61616";
    vismo_url = "http://10.0.2.111:8080";

    def __init__(self, uuid):
        self.uuid = uuid
        
    def log(self, source, target, user, tenant, xdasType, xdasStatus, parameters, resources):
        src = urlparse(source);
        if target != None:
            dest = urlparse(target);
        
        source_location = { 'host' : src.netloc, 'service' : src.path, 'user' : user, 'tenant' : tenant, 'address' : gethostbyname(src.hostname) } 
        
        if target != None:
            target_location = { 'host' : dest.netloc, 'service' : dest.path, 'user' : user, 'tenant' : tenant, 'address' : gethostbyname(dest.hostname) }
        
        params_str = json.dumps(parameters);
        description = '{0}#{1}/{2}[{3}]@{4}'.format(source, user, tenant, params_str, target)
        
        now = long(time())
        event = { 'probe' : str(self.uuid), 'type' : 'Action',  'description' : description,
                  'start' : now, 'end': now, 'resources' : resources, 'source' : source_location,
                  'target' : target_location, 'aggr_count' : 0, 'xdasType' : xdasType, 'xdasStatus' : xdasStatus,
                  'url_source' : source, 'url_target' : target, 'params_str' : params_str }
        
        conn = Connection(self.vismo_url)
        result = conn.request_post("/vismo/Monitoring/push/event", body='amq=true&event=' + json.dumps(event))
        print 'event transmission: ' + result['headers']['status']


XDAS_EventTypes = {
   'XDAS_AE_NOT_SPECIFIED': 0,
   'XDAS_AE_CREATE_ACCOUNT': 16777217,
   'XDAS_AE_DELETE_ACCOUNT': 16777218,
   'XDAS_AE_DISABLE_ACCOUNT': 16777219,
   'XDAS_AE_ENABLE_ACCOUNT': 16777220,
   'XDAS_AE_QUERY_ACCOUNT': 16777221,
   'XDAS_AE_MODIFY_ACCOUNT': 16777222,
   'XDAS_AE_CREATE_SESSION': 16777223,
   'XDAS_AE_TERMINATE_SESSION': 16777224,
   'XDAS_AE_QUERY_SESSION': 16777225,
   'XDAS_AE_MODIFY_SESSION': 16777226,
   'XDAS_AE_CREATE_DATA_ITEM': 16777227,
   'XDAS_AE_DELETE_DATA_ITEM': 16777228,
   'XDAS_AE_QUERY_DATA_ITEM_ATT': 16777229,
   'XDAS_AE_MODIFY_DATA_ITEM_ATT': 16777230,
   'XDAS_AE_INSTALL_SERVICE': 16777231,
   'XDAS_AE_REMOVE_SERVICE': 16777232,
   'XDAS_AE_QUERY_SERVICE_CONFIG': 16777233,
   'XDAS_AE_MODIFY_SERVICE_CONFIG': 16777234,
   'XDAS_AE_DISABLE_SERVICE': 16777235,
   'XDAS_AE_ENABLE_SERVICE': 16777236,
   'XDAS_AE_INVOKE_SERVICE': 16777237,
   'XDAS_AE_TERMINATE_SERVICE': 16777238,
   'XDAS_AE_QUERY_PROCESS_CONTEXT': 16777239,
   'XDAS_AE_MODIFY_PROCESS_CONTEXT': 16777240,
   'XDAS_AE_CREATE_PEER_ASSOC': 16777241,
   'XDAS_AE_TERMINATE_PEER_ASSOC': 16777242,
   'XDAS_AE_QUERY_ASSOC_CONTEXT': 16777243,
   'XDAS_AE_MODIFY_ASSOC_CONTEXT': 16777244,
   'XDAS_AE_RECEIVE_DATA_VIA_ASSOC': 16777245,
   'XDAS_AE_SEND_DATA_VIA_ASSOC': 16777246,
   'XDAS_AE_CREATE_DATA_ITEM_ASSOC': 16777247,
   'XDAS_AE_TERMINATE_DATA_ITEM_ASSOC': 16777248,
   'XDAS_AE_QUERY_DATA_ITEM_ASSOC_CONTEXT': 16777249,
   'XDAS_AE_MODIFY_DATA_ITEM_ASSOC_CONTEXT': 16777250,
   'XDAS_AE_QUERY_DATA_ITEM_CONTENTS': 16777251,
   'XDAS_AE_MODIFY_DATA_ITEM_CONTENTS': 16777252,
   'XDAS_AE_START_SYS': 16777253,
   'XDAS_AE_SHUTDOWN_SYS': 16777254,
   'XDAS_AE_RESOURCE_EXHAUST': 16777255,
   'XDAS_AE_RESOURCE_CORRUPT': 16777256,
   'XDAS_AE_BACKUP_DATASTORE': 16777257,
   'XDAS_AE_RECOVER_DATASTORE': 16777258,
   'XDAS_AE_AUD_CONFIG': 16777259,
   'XDAS_AE_AUD_DS_FULL': 16777260,
   'XDAS_AE_AUD_DS_CORR': 16777261,
   'XDAS_AE_MODIFY_AUTH_TOKEN': 33554433,
   'XDAS_AE_APPROVAL_RECEIVED': 33554434,
   'XDAS_AE_APPROVAL_REQUESTED': 33554435,
   'XDAS_AE_REQUEST_ESCALATED': 33554436,
   'XDAS_AE_NOTIFICATION_SENT': 33554437,
   'XDAS_AE_CREATE_ROLE': 33554438,
   'XDAS_AE_DELETE_ROLE': 33554439,
   'XDAS_AE_DISABLE_ROLE': 33554440,
   'XDAS_AE_ENABLE_ROLE': 33554441,
   'XDAS_AE_QUERY_ROLE': 33554442,
   'XDAS_AE_MODIFY_ROLE': 33554443
}


XDAS_Outcomes = {
   'XDAS_OUT_NOT_SPECIFIED': -1,
   'XDAS_OUT_SUCCESS': 0,
   'XDAS_OUT_PRIV_USED': 256,
   'XDAS_OUT_PRIV_GRANTED': 512,
   'XDAS_OUT_PRIV_REVOKED': 1024,
   'XDAS_OUT_PRESELECT_CRITERIA_SET': 2048,
   'XDAS_OUT_THRESHOLDS_SET': 4096,
   'XDAS_OUT_ACTIONS_SET': 8192,
   'XDAS_OUT_FAILURE': 1,
   'XDAS_OUT_SERVICE_UNAVAILABLE': 257,
   'XDAS_OUT_SERVICE_FAILURE': 513,
   'XDAS_OUT_HARDWARE_FAILURE': 1025,
   'XDAS_OUT_LOST_ASSOCIATION': 2049,
   'XDAS_OUT_ALREADY_ENABLED': 4097,
   'XDAS_OUT_ALREADY_DISABLED': 8193,
   'XDAS_OUT_SERVICE_ERROR': 16385,
   'XDAS_OUT_BUSY': 32769,
   'XDAS_OUT_DISABLED': 65537,
   'XDAS_OUT_INVALID_INPUT': 131073,
   'XDAS_OUT_ENTITY_EXISTS': 262145,
   'XDAS_OUT_ENTITY_NON_EXISTENT': 524289,
   'XDAS_OUT_DENIAL': 2,
   'XDAS_OUT_INSUFFICIENT_PRIVILEGE': 258,
   'XDAS_OUT_INVALID_IDENTITY': 514,
   'XDAS_OUT_INVALID_CREDENTIALS': 1026,
   'XDAS_OUT_RESOURCE_WAIT': 12288
}
